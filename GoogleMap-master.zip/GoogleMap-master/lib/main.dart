import 'dart:async';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(debugShowCheckedModeBanner: false, home: Home());
  }
}

class Home extends StatefulWidget {
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool servicestatus = false;
  bool haspermission = false;
  late LocationPermission permission;
  late Position position;
  static double long = 72.78544617509903, lat =  21.1869283;
  bool userMood = true;
  late StreamSubscription<Position> positionStream;
  Completer<GoogleMapController> _controller = Completer();
  @override
  void initState() {
    determinePosition().then((value) {
      setState(() {
        lat = value.latitude;
        long = value.longitude;
        print(lat);
        print(long);
      });
    });
    super.initState();
  }

  Future<Position> determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;

    // Test if location services are enabled.
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {}
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {}
    }

    if (permission == LocationPermission.deniedForever) {}

    return await Geolocator.getCurrentPosition();
  }

  static final CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(lat, long),
    zoom: 14.4746,
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text("Google Map"),
          centerTitle: true,
          backgroundColor: Colors.redAccent),
      body: Column(
        children: [
          Expanded(
            flex: 0,
            child: Column(children: [
              Text("Longitude: $long", style: TextStyle(fontSize: 20)),
              Text(
                "Latitude: $lat",
                style: TextStyle(fontSize: 20),
              )
            ]),
          ),
          Expanded(
            flex: 10,
            child: GoogleMap(
              trafficEnabled: true,
              indoorViewEnabled: true,
              mapType: userMood ? MapType.normal : MapType.satellite,
              markers: {marker},
              myLocationEnabled: true,
              initialCameraPosition: _kGooglePlex,
              onMapCreated: (GoogleMapController controller) {
                _controller.complete(controller);
              },
            ),
          )
        ],
      ),
      floatingActionButton: Row(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 30),
            child: CupertinoSwitch(
              value: userMood,
              onChanged: (bool value) {
                setState(() {
                  userMood = value;
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  Marker marker = Marker(
      markerId: MarkerId("$lat" + "$long"),
      infoWindow: InfoWindow(title: "Google Plex"),
      icon: BitmapDescriptor.defaultMarker,
      position: LatLng(lat, long));
}
